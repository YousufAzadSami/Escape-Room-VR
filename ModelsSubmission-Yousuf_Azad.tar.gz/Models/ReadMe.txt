Complex Objects
- Chandalier
- MirrorStand
- Table
- WallsDoor > Door
- Cup

Game Design
I idea is, player has to find out different numbers to escape from the room. The numbers are hidden, obviously. Some numbers will be hidden in the wall, player has to switch the lights to differnt colors to find out some of the numbers. For some numbers, player has to too shoot the lights on the wall(opposite of the door). Some number will be hidden underneath cups, glass(and some other objects, not decided yet). These number are decided into 3 groups. With these 3 group of numbers player will have to open the door.
